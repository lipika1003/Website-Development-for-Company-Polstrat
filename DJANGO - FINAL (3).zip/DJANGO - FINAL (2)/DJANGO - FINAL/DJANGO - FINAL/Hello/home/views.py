import os
import pandas as pd
from django.shortcuts import render
from django.http import HttpResponse
from twitter_scraper_selenium import scrape_profile
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import Workbook

def home(request):
    return render(request, 'home.html', {'name': 'Auditor'})

def add(request):
    if request.method == 'POST':
        
        facebook_selection = request.POST.get('facebook_dropdown', '')
        instagram_selection = request.POST.get('instagram_dropdown', '')
        twitter_selection = request.POST.get('twitter_dropdown', '')
        twitter_file = request.FILES.get('twitter_file', 'None')
        twitter_userid = request.POST.get('num3', '')  

        
        file_paths = {
            'option2': r"C:\Users\Lipika\Downloads\New folder\Facebook.xlsx",
            'option3': r"C:\Users\Lipika\Downloads\New folder\Month - Facebook.xlsx",
            'option2_instagram': r"C:\Users\Lipika\Downloads\New folder\Instagram.xlsx",
            'option3_instagram': r"C:\Users\Lipika\Downloads\New folder\Month - Instagram.xlsx",
            'option2_twitter': r"C:\Users\Lipika\Downloads\New folder\Twitter.xlsx",
            'option3_twitter': r"C:\Users\Lipika\Downloads\New folder\Month - Twitter.xlsx"
        }

        
        twitter_table_html = None
        twitter_file_path = None  
        scraped_user_ids = []  

        
        if twitter_selection == 'option2':
            if twitter_userid:
                user_ids = [twitter_userid]
            elif twitter_file:
                df_users = pd.read_excel(twitter_file)
                user_ids = df_users['Twitter_Usernames'].tolist()
            else:
                user_ids = []

            
            wb = Workbook() #create new workbook
            wb.remove(wb.active)  #removes the default active sheet from the workbook

            # for twitter_userid in df_users['Twitter_Usernames']:
            for twitter_userid in user_ids:
                scrape_profile(
                    twitter_username=twitter_userid,
                    output_format="csv",
                    browser="firefox",
                    tweets_count=10,
                    filename=twitter_userid,
                    directory=r"C:\Users\Lipika\Downloads\Twitter 2"
                )
                file_path = os.path.join(r"C:\Users\Lipika\Downloads\Twitter 2", twitter_userid + '.csv')
                df = pd.read_csv(file_path)

                
                total_likes = df['likes'].sum()
                total_retweets = df['retweets'].sum()
                total_comments = df['replies'].sum()

                num_posts = len(df)
                likes_per_post = total_likes / num_posts if num_posts else 0
                retweets_per_post = total_retweets / num_posts if num_posts else 0
                comments_per_post = total_comments / num_posts if num_posts else 0

                
                twitter_name = f"{twitter_userid}'s Twitter Data"
                Twitter = {
                    f'{twitter_name}': ['Criteria', 'Total Followers', 'Verified', 'Weekly Total Likes', 'Likes per Post', 'Weekly Retweets',
                                        'Retweets per Post', 'Comments per Week', 'Comments per Post', 'Weekly GFXs',
                                        'Personal Photos', 'Daily Post(In a Month)'],
                    'Value': ['', '', '', total_likes, likes_per_post, total_retweets, retweets_per_post, total_comments,
                              comments_per_post, '', '', '']
                }

                df_Twitter = pd.DataFrame(Twitter)
                
                # df_Twitter['Value'] = df_Twitter['Value'].apply(lambda x: f"{x:,.0f}" if isinstance(x, (int, float)) else x)
                df_Twitter['Value'] = df_Twitter['Value'].apply(lambda x: f"{x:,.0f}" if x != '' else '') #The apply method is used to apply a function to each element in the 'Value' column
#x represents each element in the 'Value' column as it is processed by the apply method.

                
                sheet = wb.create_sheet(title=twitter_userid) #Create a New Sheet in the Workbook
                for r in dataframe_to_rows(df_Twitter, index=False, header=True):#starts a loop that iterates over the rows of the df_Twitter DataFrame.
                    sheet.append(r)

                
                scraped_user_ids.append(twitter_userid)

            
                twitter_file_path = r"C:\Users\Lipika\Downloads\Twitter page scraper\Twitter_scraper.xlsx"
                wb.save(twitter_file_path)

            # Convert the workbook to HTML for display
            with pd.ExcelFile(twitter_file_path) as xls: #uses a context manager (with statement) to open an Excel file specified by twitter_file_path
                html_list = []
                for sheet_name in xls.sheet_names: #starts a loop that iterates over each sheet name in the Excel file
                    df = pd.read_excel(xls, sheet_name=sheet_name)
                    html_list.append(f"<h3>{sheet_name}</h3>" + df.to_html(index=False))

                twitter_table_html = "<br>".join(html_list)

            
            request.session['twitter_data'] = twitter_file_path #session is an attribute of the request object that provides a dictionary-like interface for storing data that persists across multiple requests from the same user.

        elif twitter_selection == 'option3':
            df = pd.read_excel(file_paths['option3_twitter'])
            twitter_table_html = df.head(10).to_html(index=False)

        facebook_table = None
        if facebook_selection == 'option2':
            df = pd.read_excel(file_paths['option2'])
            facebook_table = df.head(10).to_html(index=False)
        elif facebook_selection == 'option3':
            df = pd.read_excel(file_paths['option3'])
            facebook_table = df.head(10).to_html(index=False)

        instagram_table = None
        if instagram_selection == 'option2':
            df = pd.read_excel(file_paths['option2_instagram'])
            instagram_table = df.head(10).to_html(index=False)
        elif instagram_selection == 'option3':
            df = pd.read_excel(file_paths['option3_instagram'])
            instagram_table = df.head(10).to_html(index=False)

        
        return render(request, 'home.html', {
            'name': 'Auditor',
            'facebook_table': facebook_table,
            'instagram_table': instagram_table,
            'twitter_table': twitter_table_html,
            'twitter_name': 'Twitter Data',
            'scraped_user_ids': scraped_user_ids,  
        })

    else:
        return render(request, 'home.html', {'name': 'Auditor'})

def download_twitter_data(request):
    twitter_file_path = request.session.get('twitter_data')
    if twitter_file_path:
        with open(twitter_file_path, 'rb') as f: #opens the file specified by twitter_file_path in binary read mode ('rb').
            response = HttpResponse(f.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') #The content_type parameter is set to 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', which indicates that the response content is in the format of an Excel file (xlsx format).
            response['Content-Disposition'] = 'attachment; filename=Twitter_Scraped_Data.xlsx' #sets the Content-Disposition header of the response to indicate that the response content should be treated as an attachment (a downloadable file)
            return response
    else:
        return HttpResponse("No data to download.")



