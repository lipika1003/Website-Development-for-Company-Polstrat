# # from django.shortcuts import render, HttpResponse
# from django.shortcuts import render
# from django.http import HttpResponse
# # # Create your views here.
# def polstrat(request):
#         return render(request,'polstrat.html')

import os
import pandas as pd
from django.shortcuts import render
from django.http import HttpResponse
from twitter_scraper_selenium import scrape_profile
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import Workbook

def home(request):
    return render(request, 'home.html', {'name': 'Data Scraper'})

def add(request):
    if request.method == 'POST':
        
        facebook_selection = request.POST.get('facebook_dropdown', '')
        instagram_selection = request.POST.get('instagram_dropdown', '')
        twitter_selection = request.POST.get('twitter_dropdown', '')
        twitter_file = request.FILES.get('twitter_file', 'None')
        twitter_userid = request.POST.get('num3', '')  

        
        file_paths = {
            'option2': r"C:\Users\Gurwinder singh\Downloads\New folder\New folder\Facebook.xlsx",
            'option3': r"C:\Users\Gurwinder singh\Downloads\New folder\New folder\Month - Facebook.xlsx",
            'option2_instagram': r"C:\Users\Gurwinder singh\Downloads\New folder\New folder\Instagram.xlsx",
            'option3_instagram': r"C:\Users\Gurwinder singh\Downloads\New folder\New folder\Month - Instagram.xlsx",
            'option2_twitter': r"C:\Users\Gurwinder singh\Downloads\New folder\New folder\Twitter.xlsx",
            'option3_twitter': r"C:\Users\Gurwinder singh\Downloads\New folder\New folder\Month - Twitter.xlsx"
        }

        
        twitter_table_html = None
        twitter_file_path = None  
        scraped_user_ids = []  

        
        if twitter_selection == 'option2':
            if twitter_userid:
                user_ids = [twitter_userid]
            elif twitter_file:
                df_users = pd.read_excel(twitter_file)
                user_ids = df_users['Twitter_Usernames'].tolist()
            else:
                user_ids = []

            
            wb = Workbook() #create new workbook
            wb.remove(wb.active)  #removes the default active sheet from the workbook

            # for twitter_userid in df_users['Twitter_Usernames']:
            for twitter_userid in user_ids:
                scrape_profile(
                    twitter_username=twitter_userid,
                    output_format="csv",
                    browser="firefox",
                    tweets_count=10,
                    filename=twitter_userid,
                    directory=r"C:\Users\Gurwinder singh\Downloads\Twitter"
                )
                file_path = os.path.join(r"C:\Users\Gurwinder singh\Downloads\Twitter", twitter_userid + '.csv')
                df = pd.read_csv(file_path)

                
                total_likes = df['likes'].sum()
                total_retweets = df['retweets'].sum()
                total_comments = df['replies'].sum()

                num_posts = len(df)
                likes_per_post = total_likes / num_posts if num_posts else 0
                retweets_per_post = total_retweets / num_posts if num_posts else 0
                comments_per_post = total_comments / num_posts if num_posts else 0

                
                twitter_name = f"{twitter_userid}'s Twitter Data"
                Twitter = {
                    f'{twitter_name}': ['Criteria', 'Total Followers', 'Verified', 'Weekly Total Likes', 'Likes per Post', 'Weekly Retweets',
                                        'Retweets per Post', 'Comments per Week', 'Comments per Post', 'Weekly GFXs',
                                        'Personal Photos', 'Daily Post(In a Month)'],
                    'Value': ['', '', '', total_likes, likes_per_post, total_retweets, retweets_per_post, total_comments,
                              comments_per_post, '', '', '']
                }

                df_Twitter = pd.DataFrame(Twitter)
                
                
                df_Twitter['Value'] = df_Twitter['Value'].apply(lambda x: f"{x:,.0f}" if x != '' else '') #The apply method is used to apply a function to each element in the 'Value' column
#x represents each element in the 'Value' column as it is processed by the apply method.

                
                sheet = wb.create_sheet(title=twitter_userid) #Create a New Sheet in the Workbook
                for r in dataframe_to_rows(df_Twitter, index=False, header=True):#starts a loop that iterates over the rows of the df_Twitter DataFrame.
                    sheet.append(r)

                
                scraped_user_ids.append(twitter_userid)

            
                twitter_file_path = r"C:\Users\Gurwinder singh\Downloads\Twitter scraper\scraper.xlsx"
                wb.save(twitter_file_path)

            # Convert the workbook to HTML for display
            with pd.ExcelFile(twitter_file_path) as xls: #uses a context manager (with statement) to open an Excel file specified by twitter_file_path
                html_list = []
                for sheet_name in xls.sheet_names: #starts a loop that iterates over each sheet name in the Excel file
                    df = pd.read_excel(xls, sheet_name=sheet_name)
                    html_list.append(f"<h3>{sheet_name}</h3>" + df.to_html(index=False))

                twitter_table_html = "<br>".join(html_list)

            
            request.session['twitter_data'] = twitter_file_path #session is an attribute of the request object that provides a dictionary-like interface for storing data that persists across multiple requests from the same user.

        elif twitter_selection == 'option3':
            df = pd.read_excel(file_paths['option3_twitter'])
            twitter_table_html = df.head(10).to_html(index=False)

        facebook_table = None
        if facebook_selection == 'option2':
            df = pd.read_excel(file_paths['option2'])
            facebook_table = df.head(10).to_html(index=False)
        elif facebook_selection == 'option3':
            df = pd.read_excel(file_paths['option3'])
            facebook_table = df.head(10).to_html(index=False)

        instagram_table = None
        if instagram_selection == 'option2':
            df = pd.read_excel(file_paths['option2_instagram'])
            instagram_table = df.head(10).to_html(index=False)
        elif instagram_selection == 'option3':
            df = pd.read_excel(file_paths['option3_instagram'])
            instagram_table = df.head(10).to_html(index=False)

        
        return render(request, 'home.html', {
            'name': 'Data Scraper',
            'facebook_table': facebook_table,
            'instagram_table': instagram_table,
            'twitter_table': twitter_table_html,
            'twitter_name': 'Twitter Data',
            'scraped_user_ids': scraped_user_ids,  
        })

    else:
        return render(request, 'home.html', {'name': 'Data Scraper'})

def download_twitter_data(request):
    twitter_file_path = request.session.get('twitter_data')
    if twitter_file_path:
        with open(twitter_file_path, 'rb') as f: #opens the file specified by twitter_file_path in binary read mode ('rb').
            response = HttpResponse(f.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') #The content_type parameter is set to 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', which indicates that the response content is in the format of an Excel file (xlsx format).
            response['Content-Disposition'] = 'attachment; filename=Twitter_Scraped_Data.xlsx' #sets the Content-Disposition header of the response to indicate that the response content should be treated as an attachment (a downloadable file)
            return response
    else:
        return HttpResponse("No data to download.")

# import os
# import pandas as pd
# from django.shortcuts import render
# from django.http import HttpResponse
# from twitter_scraper_selenium import scrape_profile
# from openpyxl.utils.dataframe import dataframe_to_rows
# from openpyxl import Workbook
# from django.http import FileResponse

# def home(request):
#     return render(request, 'home.html', {'name': 'WEBSITE'})

# def add(request):
#     if request.method == 'POST':
#         # Retrieve values from form
#         facebook_selection = request.POST.get('facebook_dropdown', '')
#         instagram_selection = request.POST.get('instagram_dropdown', '')
#         twitter_selection = request.POST.get('twitter_dropdown', '')
#         twitter_file = request.FILES.get('twitter_file', '')
#         twitter_userid = request.POST.get('num3', '')  # Add this line

#         # Dictionary mapping dropdown values to file paths
#         file_paths = {
#             'option2': r"C:\Users\Lipika\Downloads\New folder\Facebook.xlsx",
#             'option3': r"C:\Users\Lipika\Downloads\New folder\Month - Facebook.xlsx",
#             'option2_instagram': r"C:\Users\Lipika\Downloads\New folder\Instagram.xlsx",
#             'option3_instagram': r"C:\Users\Lipika\Downloads\New folder\Month - Instagram.xlsx",
#             'option2_twitter': r"C:\Users\Lipika\Downloads\New folder\Twitter.xlsx",
#             'option3_twitter': r"C:\Users\Lipika\Downloads\New folder\Month - Twitter.xlsx"
#         }

#         # Initialize variables
#         twitter_table_html = None
#         twitter_file_path = None  # Variable to store the path of the generated Excel file

#         # Process the uploaded Twitter file and scrape data if 1-week data option is selected
#         if twitter_selection == 'option2' and twitter_file:
#             # Load the Excel file containing Twitter usernames
#             df_users = pd.read_excel(twitter_file)

#             # Create a new workbook
#             wb = Workbook()
#             wb.remove(wb.active)  # Remove the default sheet

#             for twitter_userid in df_users['Twitter_Usernames']:
#                 scrape_profile(
#                     twitter_username=twitter_userid,
#                     output_format="csv",
#                     browser="firefox",
#                     tweets_count=10,
#                     filename=twitter_userid,
#                     directory=r"C:\Users\Lipika\Downloads\Facebook page scraper"
#                 )
#                 file_path = os.path.join(r"C:\Users\Lipika\Downloads\Facebook page scraper", twitter_userid + '.csv')
#                 df = pd.read_csv(file_path)

#                 # Calculate metrics (ensure the column names match your DataFrame)
#                 total_likes = df['likes'].sum()
#                 total_retweets = df['retweets'].sum()
#                 total_comments = df['replies'].sum()

#                 num_posts = len(df)
#                 likes_per_post = total_likes / num_posts if num_posts else 0
#                 retweets_per_post = total_retweets / num_posts if num_posts else 0
#                 comments_per_post = total_comments / num_posts if num_posts else 0

#                 # Create a DataFrame for Twitter data
#                 twitter_name = f"{twitter_userid}'s Twitter Data"
#                 Twitter = {
#                     f'{twitter_name}': ['Criteria','Total Followers', 'Verified', 'Weekly Total Likes', 'Likes per Post', 'Weekly Retweets',
#                                  'Retweets per Post', 'Comments per Week', 'Comments per Post', 'Weekly GFXs',
#                                  'Personal Photos', 'Daily Post(In a Month)'],
#                     'Value': ['','', '', total_likes, likes_per_post, total_retweets, retweets_per_post, total_comments,
#                               comments_per_post, '', '', '']
#                 }

#                 df_Twitter = pd.DataFrame(Twitter)
                
#                 # Format the numbers, except for blank values
#                 df_Twitter['Value'] = df_Twitter['Value'].apply(lambda x: f"{x:,.0f}" if x != '' else '')

#                 # Add the DataFrame to a new sheet in the workbook
#                 sheet = wb.create_sheet(title=twitter_userid)
#                 for r in dataframe_to_rows(df_Twitter, index=False, header=True):
#                     sheet.append(r)

#             # Save the workbook to a file
#             twitter_file_path = r"C:\Users\Lipika\Downloads\Twitter_Scraped_Data.xlsx"
#             wb.save(twitter_file_path)

#             # Convert the workbook to HTML for display
#             with pd.ExcelFile(twitter_file_path) as xls:
#                 html_list = []
#                 for sheet_name in xls.sheet_names:
#                     df = pd.read_excel(xls, sheet_name=sheet_name)
#                     html_list.append(f"<h3>{sheet_name}</h3>" + df.to_html(index=False))

#                 twitter_table_html = "<br>".join(html_list)

#             # Save the DataFrame to the session for later download
#             request.session['twitter_data'] = twitter_file_path

#         elif twitter_selection == 'option3':
#             df = pd.read_excel(file_paths['option3_twitter'])
#             twitter_table_html = df.head(10).to_html(index=False)

#         facebook_table = None
#         if facebook_selection == 'option2':
#             df = pd.read_excel(file_paths['option2'])
#             facebook_table = df.head(10).to_html(index=False)
#         elif facebook_selection == 'option3':
#             df = pd.read_excel(file_paths['option3'])
#             facebook_table = df.head(10).to_html(index=False)

#         instagram_table = None
#         if instagram_selection == 'option2':
#             df = pd.read_excel(file_paths['option2_instagram'])
#             instagram_table = df.head(10).to_html(index=False)
#         elif instagram_selection == 'option3':
#             df = pd.read_excel(file_paths['option3_instagram'])
#             instagram_table = df.head(10).to_html(index=False)

#         # Pass data to template
#         return render(request, 'home.html', {
#             'name': 'WEBSITE',
#             'facebook_table': facebook_table,
#             'instagram_table': instagram_table,
#             'twitter_table': twitter_table_html,
#             'twitter_name': 'Twitter Data',
#         })

#     else:
#         return render(request, 'home.html', {'name': 'WEBSITE'})

# def download_twitter_data(request):
#     twitter_file_path = request.session.get('twitter_data')
#     if twitter_file_path:
#         with open(twitter_file_path, 'rb') as f:
#             response = HttpResponse(f.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
#             response['Content-Disposition'] = 'attachment; filename=Twitter_Scraped_Data.xlsx'
#             return response
#     else:
#         return HttpResponse("No data to download.")

# # import os
# # import pandas as pd
# # from django.shortcuts import render
# # from django.http import HttpResponse
# # from twitter_scraper_selenium import scrape_profile
# # from openpyxl.utils.dataframe import dataframe_to_rows
# # from openpyxl import Workbook
# # import tempfile
# # from django.http import FileResponse
# # from tempfile import NamedTemporaryFile

# # def home(request):
# #     return render(request, 'home.html', {'name': 'WEBSITE'})

# # # import os
# # # import pandas as pd
# # # from django.shortcuts import render
# # # from django.http import HttpResponse
# # # from twitter_scraper_selenium import scrape_profile
# # # from tempfile import NamedTemporaryFile
# # # from openpyxl import Workbook

# # def add(request):
# #     if request.method == 'POST':
# #         # Retrieve values from form
# #         facebook_selection = request.POST.get('facebook_dropdown', '')
# #         instagram_selection = request.POST.get('instagram_dropdown', '')
# #         twitter_selection = request.POST.get('twitter_dropdown', '')
# #         twitter_userid = request.POST.get('num3', '')
# #         twitter_file = request.FILES.get('twitter_file', '')

# #         # Dictionary mapping dropdown values to file paths
# #         file_paths = {
# #             'option2': r"C:\Users\Lipika\Downloads\New folder\Facebook.xlsx",  # Example path for Facebook 1 Week data
# #             'option3': r"C:\Users\Lipika\Downloads\New folder\Month - Facebook.xlsx",  # Example path for Facebook 1 Month data
# #             'option2_instagram': r"C:\Users\Lipika\Downloads\New folder\Instagram.xlsx",  # Example path for Instagram 1 Week data
# #             'option3_instagram': r"C:\Users\Lipika\Downloads\New folder\Month - Instagram.xlsx",  # Example path for Instagram 1 Month data
# #             'option2_twitter': r"C:\Users\Lipika\Downloads\New folder\Twitter.xlsx",  # Example path for Twitter 1 Week data
# #             'option3_twitter': r"C:\Users\Lipika\Downloads\New folder\Month - Twitter.xlsx"
# #         }

# #         # Initialize variables
# #         twitter_table_html = None
# #         twitter_file_path = None  # Variable to store the path of the generated Excel file

# #         # Scrape Twitter data if the 1-week data option is selected
# #         if twitter_selection == 'option2' and twitter_file:
# #             df_users = pd.read_excel(twitter_file)

# #             # Create a new DataFrame to store the scraped data
# #             all_data = []

# #             for twitter_userid in df_users['Twitter_Usernames']:
# #                 scrape_profile(
# #                 twitter_username=twitter_userid,
# #                 output_format="csv",
# #                 browser="firefox",
# #                 tweets_count=10,
# #                 filename=twitter_userid,
# #                 directory=r"C:\Users\Lipika\Downloads\Facebook page scraper"
# #             )
# #             file_path = os.path.join(r"C:\Users\Lipika\Downloads\Facebook page scraper", twitter_userid + '.csv')
# #             df = pd.read_csv(file_path)

# #             # Calculate metrics (ensure the column names match your DataFrame)
# #             total_likes = df['likes'].sum()
# #             total_retweets = df['retweets'].sum()
# #             total_comments = df['replies'].sum()

# #             num_posts = len(df)
# #             likes_per_post = total_likes / num_posts if num_posts else 0
# #             retweets_per_post = total_retweets / num_posts if num_posts else 0
# #             comments_per_post = total_comments / num_posts if num_posts else 0

# #             # Create a DataFrame for Twitter data
# #             twitter_name = f"{twitter_userid}'s Twitter Data"
# #             Twitter = {
# #                 f'{twitter_name}': ['Criteria','Total Followers', 'Verified', 'Weekly Total Likes', 'Likes per Post', 'Weekly Retweets',
# #                              'Retweets per Post', ' Comments per Week', 'Comments per Post', 'Weekly GFXs',
# #                              'Personal Photos', 'Daily Post(In a Month)'],
# #                 'Value': ['','', '', total_likes, likes_per_post, total_retweets, retweets_per_post, total_comments,
# #                           comments_per_post, '', '', '']
# #             }

# #             df_Twitter = pd.DataFrame(Twitter)

# #             # Format the numbers, except for blank values
# #             df_Twitter['Value'] = df_Twitter['Value'].apply(lambda x: f"{x:,.0f}" if x != '' else '')

# #         all_data.append(df_Twitter)

# #             # Combine all DataFrames
# #         df_all_data = pd.concat(all_data, ignore_index=True)

# #             # Save the DataFrame to a new Excel file
# #         twitter_file_path = r"C:\Users\Lipika\Downloads\Twitter_Scraped_Data.xlsx"
#         df_all_data.to_excel(twitter_file_path, index=False)

#         twitter_table_html = df_all_data.to_html(index=False)

#             # Save the DataFrame to the session for later download
#         request.session['twitter_data'] = df_Twitter.to_dict(orient='list')

#     elif twitter_selection == 'option3':
#         df = pd.read_excel(file_paths['option3_twitter'])
#         twitter_table = df.head(10).to_html(index=False)

#         facebook_table = None
#         if facebook_selection == 'option2':
#             df = pd.read_excel(file_paths['option2'])
#             facebook_table = df.head(10).to_html(index=False)
#         elif facebook_selection == 'option3':
#             df = pd.read_excel(file_paths['option3'])
#             facebook_table = df.head(10).to_html(index=False)

#         instagram_table = None
#         if instagram_selection == 'option2':
#             df = pd.read_excel(file_paths['option2_instagram'])
#             instagram_table = df.head(10).to_html(index=False)
#         elif instagram_selection == 'option3':
#             df = pd.read_excel(file_paths['option3_instagram'])
#             instagram_table = df.head(10).to_html(index=False)

#         # Pass data to template
#         return render(request, 'home.html', {
#             'name': 'WEBSITE',
#             'facebook_table': facebook_table,
#             'instagram_table': instagram_table,
#             'twitter_table': twitter_table_html,
#             'twitter_name': twitter_name,
#         })

#     else:
#         return render(request, 'home.html', {'name': 'WEBSITE'})

# def download_twitter_data(request):
#     twitter_data = request.session.get('twitter_data')
#     if twitter_data:
#         df_Twitter = pd.DataFrame(twitter_data)
#         excel_file_path = r"C:\Users\Lipika\Downloads\Twitter_Data.xlsx"
#         df_Twitter.to_excel(excel_file_path, index=False)

#         with open(excel_file_path, 'rb') as f:
#             response = HttpResponse(f.read(), content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
#             response['Content-Disposition'] = 'attachment; filename=Twitter_Data.xlsx'
#             return response
#     else:
#         return HttpResponse("No data to download.")

# # import tempfile
# # from django.shortcuts import render
# # from django.http import HttpResponse

# # import openpyxl
# # import pandas as pd
# # from twitter_scraper_selenium import scrape_profile
# # import os
# # # # Create your views here.
# # # # def home(request):
# # #     return HttpResponse('Hello World')
# # def home(request):
# #     return render(request, 'home.html', {'name': 'WEBSITE'})

# # def add(request):
# #     if request.method == 'POST':
# #         # Retrieve values from form
# #         facebook_selection = request.POST.get('facebook_dropdown', '')
# #         instagram_selection = request.POST.get('instagram_dropdown', '')
# #         twitter_selection = request.POST.get('twitter_dropdown', '')
# #         twitter_userid = request.POST.get('num3', '')

# #         # Dictionary mapping dropdown values to file paths
#         # file_paths = {
#         #     'option2': r"C:\Users\Lipika\Downloads\New folder\Facebook.xlsx",  # Example path for Facebook 1 Week data
#         #     'option3': r"C:\Users\Lipika\Downloads\New folder\Month - Facebook.xlsx",  # Example path for Facebook 1 Month data
#         #     'option2_instagram': r"C:\Users\Lipika\Downloads\New folder\Instagram.xlsx",  # Example path for Instagram 1 Week data
#         #     'option3_instagram': r"C:\Users\Lipika\Downloads\New folder\Month - Instagram.xlsx",  # Example path for Instagram 1 Month data
#         #     'option2_twitter': r"C:\Users\Lipika\Downloads\New folder\Twitter.xlsx",  # Example path for Twitter 1 Week data
#         #     'option3_twitter': r"C:\Users\Lipika\Downloads\New folder\Month - Twitter.xlsx"
#         # }

# #         # Initialize variables
# #         twitter_table = None
# #         twitter_file_path = None

# #         # Scrape Twitter data if the 1-week data option is selected
# #         if twitter_selection == 'option2':
# #             scrape_profile(
# #                 twitter_username=twitter_userid,
# #                 output_format="csv",
# #                 browser="firefox",
# #                 tweets_count=10,
# #                 filename=twitter_userid,
# #                 directory=r"C:\Users\Lipika\Downloads\Facebook page scraper"
# #             )
#             file_path = os.path.join(r"C:\Users\Lipika\Downloads\Facebook page scraper", twitter_userid + '.csv')
#             df = pd.read_csv(file_path)

#             # Calculate metrics (ensure the column names match your DataFrame)
#             total_likes = df['likes'].sum()
#             total_retweets = df['retweets'].sum()
#             total_comments = df['replies'].sum()

#             num_posts = len(df)
#             likes_per_post = total_likes / num_posts if num_posts else 0
#             retweets_per_post = total_retweets / num_posts if num_posts else 0
#             comments_per_post = total_comments / num_posts if num_posts else 0

#             Twitter = {
#                 'Twitter Data': ['Criteria','Total Followers','Verified','Weekly Total Likes', 'Likes per Post', 'Weekly Retweets', 'Retweets per Post', ' Comments per Week', 'Comments per Post','Weekly GFXs', 'Personal Photos', 'Daily Post(In a Month)'],
#                 'Value': ['','','',total_likes, likes_per_post, total_retweets, retweets_per_post, total_comments, comments_per_post,'','','']
#             }

#             df_Twitter = pd.DataFrame(Twitter)

#             # Format the numbers, except for blank values
#             df_Twitter['Value'] = df_Twitter['Value'].apply(lambda x: f"{x:,.0f}" if x != '' else '')

#             twitter_table = df_Twitter.to_html(index=False)

#             # twitter_table = df_Twitter.to_html(index=False)

#             # Save the DataFrame to Excel temporarily
#             temp_file_path = tempfile.NamedTemporaryFile().name
#             df_Twitter.to_excel(temp_file_path, index=False)
#             twitter_file_path = temp_file_path
            
#         elif twitter_selection == 'option3':
#             df = pd.read_excel(file_paths['option3_twitter'])
#             twitter_table = df.head(10).to_html(index=False)
#             # twitter_table = pd.DataFrame(metrics).to_html(index=False)
#         # elif twitter_selection == 'option3':
#         #     df = pd.read_excel(file_paths['option3_twitter'])
#         #     twitter_table = df.head(10).to_html(index=False)

#         # Read Excel file into pandas DataFrame based on selection
#         facebook_table = None
#         if facebook_selection == 'option2':
#             df = pd.read_excel(file_paths['option2'])
#             facebook_table = df.head(10).to_html(index=False)
#         elif facebook_selection == 'option3':
#             df = pd.read_excel(file_paths['option3'])
#             facebook_table = df.head(10).to_html(index=False)

#         instagram_table = None
#         if instagram_selection == 'option2':
#             df = pd.read_excel(file_paths['option2_instagram'])
#             instagram_table = df.head(10).to_html(index=False)
#         elif instagram_selection == 'option3':
#             df = pd.read_excel(file_paths['option3_instagram'])
#             instagram_table = df.head(10).to_html(index=False)

#         # Pass data to template
#         return render(request, 'home.html', {
#             'name': 'WEBSITE',
#             'facebook_table': facebook_table,
#             'instagram_table': instagram_table,
#             'twitter_table': twitter_table,
#         })

#     else:
#         return render(request, 'home.html', {'name': 'WEBSITE'})
    
# # def download_twitter_data(request):
# #     if request.method == 'POST':
# #         # Retrieve Twitter table HTML from form data
# #         twitter_table_html = request.POST.get('twitter_table', '')

# #         # Convert HTML table to DataFrame
# #         df = pd.read_html(twitter_table_html)[0]  # Assuming only one table is passed

# #         # Create a temporary file to save Excel
# #         temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
# #         excel_path = temp_file.name

# #         # Save DataFrame to Excel
# #         df.to_excel(excel_path, index=False)
# #         temp_file.close()

# #         # Open and read the file
# #         with open(excel_path, 'rb') as excel_file:
# #             response = HttpResponse(excel_file.read(),
# #                                     content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
# #             response['Content-Disposition'] = 'attachment; filename=twitter_data.xlsx'
# #             return response

# #     # Handle the case where there's no POST data or other errors
# #     return HttpResponse('Error downloading file.')
# # def add(request):
# #     if request.method == 'POST':
# #         # Retrieve values from form
# #         facebook_selection = request.POST.get('facebook_dropdown', '')
# #         instagram_selection = request.POST.get('instagram_dropdown', '')
# #         twitter_selection = request.POST.get('twitter_dropdown', '')
# #         twitter_userid = request.POST.get('num3', '')
# #         # print(twitter_userid)

# #         # Dictionary mapping dropdown values to file paths
# #         file_paths = {
# #             'option2': r"C:\Users\Lipika\Downloads\New folder\Facebook.xlsx",  # Example path for Facebook 1 Week data
# #             'option3': r"C:\Users\Lipika\Downloads\New folder\Month - Facebook.xlsx",  # Example path for Facebook 1 Month data
# #             'option2_instagram': r"C:\Users\Lipika\Downloads\New folder\Instagram.xlsx",  # Example path for Instagram 1 Week data
# #             'option3_instagram': r"C:\Users\Lipika\Downloads\New folder\Month - Instagram.xlsx",  # Example path for Instagram 1 Month data
# #             'option2_twitter': r"C:\Users\Lipika\Downloads\New folder\Twitter.xlsx",  # Example path for Twitter 1 Week data
# #             'option3_twitter': r"C:\Users\Lipika\Downloads\New folder\Month - Twitter.xlsx"
# #         }

# #         # Scrape Twitter data if the 1-week data option is selected
# #         if twitter_selection == 'option2':
# #             scrape_profile(
# #                 twitter_username= twitter_userid,
# #                 output_format="csv",
# #                 browser="firefox",
# #                 tweets_count=10,
# #                 filename= twitter_userid,
# #                 directory=r"C:\Users\Lipika\Downloads\Facebook page scraper"
# #             )
# #             file_path = os.path.join(r"C:\Users\Lipika\Downloads\Facebook page scraper", twitter_userid+ '.csv')
# #             df = pd.read_csv(file_path)
# #             twitter_table = df.head(10).to_html(index=False)
# #         elif twitter_selection == 'option3':
# #             df = pd.read_excel(file_paths['option3_twitter'])
# #             twitter_table = df.head(10).to_html(index=False)
# #         else:
# #             twitter_table = None

# #         # Read Excel file into pandas DataFrame based on selection
# #         if facebook_selection == 'option2':
# #             df = pd.read_excel(file_paths['option2'])
# #             facebook_table = df.head(10).to_html(index=False)
# #         elif facebook_selection == 'option3':
# #             df = pd.read_excel(file_paths['option3'])
# #             facebook_table = df.head(10).to_html(index=False)
# #         else:
# #             facebook_table = None

# #         if instagram_selection == 'option2':
# #             df = pd.read_excel(file_paths['option2_instagram'])
# #             instagram_table = df.head(10).to_html(index=False)
# #         elif instagram_selection == 'option3':
# #             df = pd.read_excel(file_paths['option3_instagram'])
# #             instagram_table = df.head(10).to_html(index=False)
# #         else:
# #             instagram_table = None

# #         # Pass data to template
# #         return render(request, 'home.html', {
# #             'name': 'WEBSITE',
# #             'facebook_table': facebook_table,
# #             'instagram_table': instagram_table,
# #             'twitter_table': twitter_table,
# #         })

# #     else:
# #         return render(request, 'home.html', {'name': 'WEBSITE'})
# # # def add(request):
# # #     if request.method == 'POST':
# # #         # Retrieve values from form
# # #         facebook_selection = request.POST.get('facebook_dropdown', '')
# # #         instagram_selection = request.POST.get('instagram_dropdown', '')
# # #         twitter_selection = request.POST.get('twitter_dropdown', '')

# # # #         # Dictionary mapping dropdown values to file paths
# # # #         file_paths = {
# # # #             'option2': r"C:\Users\Lipika\Downloads\New folder\Facebook.xlsx",  # Example path for Facebook 1 Week data
# # # #             'option3': r"C:\Users\Lipika\Downloads\New folder\Month - Facebook.xlsx",  # Example path for Facebook 1 Month data
# # # #             'option2_instagram': r"C:\Users\Lipika\Downloads\New folder\Instagram.xlsx",  # Example path for Instagram 1 Week data
# # # #             'option3_instagram': r"C:\Users\Lipika\Downloads\New folder\Month - Instagram.xlsx",  # Example path for Instagram 1 Month data
# # # #             'option2_twitter': r"C:\Users\Lipika\Downloads\New folder\Twitter.xlsx",  # Example path for Twitter 1 Week data
# # # #             'option3_twitter': r"C:\Users\Lipika\Downloads\New folder\Month - Twitter.xlsx"
# # # #     }

# # # #         # Read Excel file into pandas DataFrame based on selection
# # # #         if facebook_selection == 'option2':
# # #             df = pd.read_excel(file_paths['option2'])
# # #             facebook_table = df.head(10).to_html(index=False)
# # #         elif facebook_selection == 'option3':
# # #             df = pd.read_excel(file_paths['option3'])
# # #             facebook_table = df.head(10).to_html(index=False)
# # #         else:
# # #             facebook_table = None

# # #         if instagram_selection == 'option2':
# # #             df = pd.read_excel(file_paths['option2_instagram'])
# # #             instagram_table = df.head(10).to_html(index=False)
# # #         elif instagram_selection == 'option3':
# # #             df = pd.read_excel(file_paths['option3_instagram'])
# # #             instagram_table = df.head(10).to_html(index=False)
# #         else:
# #             instagram_table = None

# #         if twitter_selection == 'option2':
# #             df = pd.read_excel(file_paths['option2_twitter'])
# #             twitter_table = df.head(10).to_html(index=False)
# #         elif twitter_selection == 'option3':
# #             df = pd.read_excel(file_paths['option3_twitter'])
# #             twitter_table = df.head(10).to_html(index=False)
# #         else:
# #             twitter_table = None

# #         # Pass data to template
# #         return render(request, 'home.html', {
# #             'name': 'WEBSITE',
# #             'facebook_table': facebook_table,
# #             'instagram_table': instagram_table,
# #             'twitter_table': twitter_table,
# #         })

# #     else:
# #         return render(request, 'home.html', {'name': 'WEBSITE'})
# # # # def home(request):
# # # # #         # return render(request, 'home.html')
# # # #         return render (request, 'home.html',{'name':'WEBSITE'})
# # # # def home(request):
# # # #         # return render(request, 'home.html')
# # # #         return render (request, 'home.html',{'name':'WEBSITE'})
# # # #     # val1 = str(request.POST['num1'])
# # # #     # val2 = str(request.POST['num2'])
# # # #     # val3 = str(request.POST['num3'])

# # # # #     # file_path = r"C:\Users\Lipika\Downloads\Django - Project.xlsx"

# # # # #     # df = pd.read_excel(file_path)
# # # # #     # html_table = df.to_html(index=False)

# # # # #     # return render (request, 'home.html',{'name':'WEBSITE'},"result.html",{'table':html_table} )
# # # # # # def add(request):

# # # # # def add(request):
# # # # #     if request.method == 'POST':
# # # # #         # Process form data (assuming you have num1, num2, num3 fields)
# # # # #         val1 = str(request.POST.get('num1', ''))
# # # # #         val2 = str(request.POST.get('num2', ''))
# # # # #         val3 = str(request.POST.get('num3', ''))

# # # # #         # Example path to your Excel file
# # # # #         file_path = r"C:\Users\Lipika\Downloads\Django - Project.xlsx"

# # # # #         # Read Excel file into pandas DataFrame
# # # # #         df = pd.read_excel(file_path)

# # # # #         # Prepare the data you want to pass to the template
# # # # #         html_table = df.head(10).to_html(index=False)  # Displaying only first 10 rows for example

# # # # #         # Render the home.html template with the table data
# # # # #         return render(request, 'home.html', {'name': 'WEBSITE', 'table': html_table})

# # # # #     else:
# # # # #         return render(request, 'home.html', {'name': 'WEBSITE'})
# # # # # # def add(request):
# # # # # #     if request.method == 'POST':
# # # # # #         # Fetch data from POST request
# # # # # #         facebook_data = request.POST.get('facebook_dropdown', '')
# # # # # #         instagram_data = request.POST.get('instagram_dropdown', '')
# # # # # #         twitter_data = request.POST.get('twitter_dropdown', '')

# # # # # #         # Define paths to your Excel files
# # # # # #         facebook_file_path = r"C:\Users\Lipika\Downloads\New folder\Facebook.xlsx"
# # # # # #         instagram_file_path = r"C:\Users\Lipika\Downloads\New folder\Instagram.xlsx"
# # # # # #         twitter_file_path = r"C:\Users\Lipika\Downloads\New folder\Twitter.xlsx"

# # # # # #         # Initialize variables to store table HTML
# # # # # #         facebook_table = ''
# # # # # #         instagram_table = ''
# # # # #         twitter_table = ''

# # # # #         # Read data from Excel files
# # # # #         if facebook_data == 'option1':  # 1 Week Data for Facebook
# # # # #             facebook_table = read_excel_to_html(facebook_file_path, sheet_name='Sheet1')

# # # # #         if instagram_data == 'option1':  # 1 Week Data for Instagram
# # # # #             instagram_table = read_excel_to_html(instagram_file_path, sheet_name='Sheet1')

# # # # #         if twitter_data == 'option1':  # 1 Week Data for Twitter
# # # # #             twitter_table = read_excel_to_html(twitter_file_path, sheet_name='Sheet1')

# # # # #         # Render the home.html template with the table data
# # # # #         return render(request, 'home.html', {
# # # # #             'name': 'WEBSITE',
# # # #             'facebook_table': facebook_table,
# # # #             'instagram_table': instagram_table,
# # # #             'twitter_table': twitter_table
# # # #         })

# # # #     else:
# # # #         return render(request, 'home.html', {'name': 'WEBSITE'})

# # # # def read_excel_to_html(file_path, sheet_name):
# # # #     workbook = openpyxl.load_workbook(file_path)
# # # #     sheet = workbook[sheet_name]

# # # #     html_table = '<table border="1">'

# # #     for row in sheet.iter_rows(values_only=True):
# # #         html_table += '<tr>'
# # #         for cell in row:
# # #             html_table += f'<td>{cell}</td>'
# # #         html_table += '</tr>'

# # #     html_table += '</table>'
# # #     return html_table



# #     # val1 = int(request.GET['num1'])
# #     # val2 = int(request.GET['num2'])
# #     # res = val1 + val2

# #     # val1 = str(request.POST['num1'])
# #     # val2 = str(request.POST['num2'])
# #     # val3 = str(request.POST['num3'])

# #     # file_path = r"C:\Users\Lipika\Downloads\Django - Project.xlsx"

# #     # df = pd.read_excel(file_path)
# #     # html_table = df.to_html(index=False)


# #     # res = val1

# #     # res = val1, val2,val3
# #     # return render(request, "result.html",{'table':html_table} )

# # # Create your views here.
# # # def home(request):
# # #     return HttpResponse('Hello World')
# # # def home(request):
# # #     # return render(request, 'home.html')
# # #     return render (request, 'home.html',{'name':'Lipika'})
# # # context ={
# # #         'variable1': "Harry is great",
# # #         'variable2': "Rohan is great"
# # # }
# # # def social(request):

# # #     # val1 = int(request.GET['num1'])
# # #     # val2 = int(request.GET['num2'])
# # #     # res = val1 + val2

# # #     val1 = str(request.POST['num1'])
# # #     val2 = str(request.POST['num2'])
# # #     res = val1 + val2

# # #     return render(request, "result.html",{'result':res} )

# #     # return HttpResponse("this is homepage")

    
# # # def about(request):
# # #     return render(request,'about.html')
# #     # return HttpResponse("this is about page")
# # # def services(request):
# # #     return render(request,'services.html')
# #     # return HttpResponse("this is services page")
# # # def contact(request):
# # #     return render(request,'contact.html')
# #     # return HttpResponse("this is contact page")
# # # context ={
# # #         'variable1': "Harry is great",
# # #         'variable2': "Rohan is great"