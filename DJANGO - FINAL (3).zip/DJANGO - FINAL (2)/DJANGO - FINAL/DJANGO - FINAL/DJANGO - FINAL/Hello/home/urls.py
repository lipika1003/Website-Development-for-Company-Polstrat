from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
     path('', views.home, name='home'),
     path('add', views.add, name='add'),
     path('download_twitter_data', views.download_twitter_data, name='download_twitter_data'),
]

# from django.contrib import admin
# from django.urls import path
# from home import views

# urlpatterns = [
#      path('',views.home, name='home'),
#      path('add',views.add,name='add'),
#       path('download_twitter_data', views.download_twitter_data, name='download_twitter_data'),
# ]
     


   
    # path("about",views.about,name='about'),
    # path("services",views.services,name='services'),
    # path("contact",views.contact,name='contact')



